<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* profile/index.twig */
class __TwigTemplate_f363bf514e83960c060c2c31a101f421 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.twig", "profile/index.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    ";
        // line 5
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("profile");
        echo "
";
    }

    // line 8
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    ";
        // line 10
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("profile");
        echo "
";
    }

    // line 13
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Profile";
    }

    // line 15
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 16
        echo "    <div class=\"profile container content-body\">
        <h1>Profile</h1>
        <form>
            <div class=\"row d-flex align-items-center\">
                <div class=\"col-md-4\">
                    <label for=\"email\" class=\"form-label\">Email</label>
                    <input type=\"email\" class=\"form-control\" id=\"email\" name=\"email\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["profileData"] ?? null), "email", [], "any", false, false, false, 22), "html", null, true);
        echo "\" disabled>
                </div>
                <div class=\"col-md-4\">
                    <label for=\"name\" class=\"form-label\">Name</label>
                    <input type=\"text\" class=\"form-control\" id=\"name\" name=\"name\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["profileData"] ?? null), "name", [], "any", false, false, false, 26), "html", null, true);
        echo "\">
                </div>
                <div class=\"col-md-4\">
                    <label class=\"form-label\">&nbsp;</label>
                    <div class=\"form-check\">
                        <input type=\"checkbox\"
                               class=\"form-check-input\"
                               id=\"twoFactor\"
                               value=\"1\"
                               name=\"twoFactor\" ";
        // line 35
        echo ((twig_get_attribute($this->env, $this->source, ($context["profileData"] ?? null), "twoFactor", [], "any", false, false, false, 35)) ? ("checked") : (""));
        echo ">
                        <label class=\"form-check-label\" for=\"twoFactor\">Enable 2FA via Email</label>
                    </div>
                </div>
            </div>
            <div class=\"mt-4 row justify-content-center\">
                <div class=\"col-md-4 d-flex gap-2\">
                    <button type=\"button\"
                            class=\"btn btn-outline-primary\"
                            data-bs-toggle=\"modal\"
                            data-bs-target=\"#updatePasswordModal\">
                        <i class=\"bi bi-key-fill me-1\"></i> Update Password
                    </button>
                    <button type=\"button\" class=\"btn btn-primary save-profile\">
                        <i class=\"bi bi-check2-circle me-1\"></i> Save Changes
                    </button>
                </div>
            </div>
        </form>
        ";
        // line 54
        $this->loadTemplate("profile/update_password_modal.twig", "profile/index.twig", 54)->display($context);
        // line 55
        echo "    </div>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "profile/index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  141 => 55,  139 => 54,  117 => 35,  105 => 26,  98 => 22,  90 => 16,  86 => 15,  79 => 13,  73 => 10,  68 => 9,  64 => 8,  58 => 5,  53 => 4,  49 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "profile/index.twig", "C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\views\\profile\\index.twig");
    }
}
