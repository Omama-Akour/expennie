<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* categories/index.twig */
class __TwigTemplate_649779458dbee0637cdcca8e69fbddda extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "{extends 'layout.tpl'}

{block name=\"javascripts\"}
    {\$smarty.block.parent}
    {include file='categories.js.tpl'}
{/block}

{block name=\"title\"}Categories{/block}

{block name=\"content\"}
    <div class=\"categories container content-body\">
        <div class=\"text-end mb-4\">
            <button type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#newCategoryModal\">
                <i class=\"bi bi-plus-circle me-1\"></i>
                New Category
            </button>
        </div>
        <div class=\"modal fade\" id=\"newCategoryModal\" tabindex=\"-1\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                <form action=\"/categories\" method=\"post\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <h5 class=\"modal-title\">New Category</h5>
                            <button type=\"button\" class=\"btn-close\" data-dismiss=\"modal\" aria-label=\"Close\"></button>
                        </div>
                        <div class=\"modal-body\">
                            {\$csrf.fields}
                            <div class=\"form-outline form-white mb-4\">
                                <input type=\"text\" name=\"name\" required
                                       class=\"form-control form-control-lg\"
                                       placeholder=\"Category Name\" />
                            </div>
                        </div>
                        <div class=\"modal-footer\">
                            <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">
                                <i class=\"bi bi-x-circle me-1\"></i>
                                Close
                            </button>
                            <button type=\"submit\" class=\"btn btn-success\">
                                <i class=\"bi bi-check-circle me-1\"></i>
                                Create
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        {include file='categories/edit_category_modal.tpl'}
        <div>
            <table id=\"categoriesTable\">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
{/block}
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "categories/index.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "categories/index.twig", "C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\views\\categories\\index.twig");
    }
}
