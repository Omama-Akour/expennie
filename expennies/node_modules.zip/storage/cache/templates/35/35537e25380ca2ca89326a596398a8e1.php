<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* profile/update_password_modal.twig */
class __TwigTemplate_e64b7166393eea0484db12c546b3caa1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"modal fade\" id=\"updatePasswordModal\" tabindex=\"-1\" aria-labelledby=\"updatePasswordModalLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"updatePasswordModalLabel\">Update Password</h5>
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
            </div>
            <div class=\"modal-body\">
                <form id=\"passwordForm\">
                    <div class=\"mb-3\">
                        <label for=\"currentPassword\" class=\"form-label\">Current Password</label>
                        <input type=\"password\" class=\"form-control\" id=\"currentPassword\" name=\"currentPassword\">
                    </div>
                    <div class=\"mb-3\">
                        <label for=\"newPassword\" class=\"form-label\">New Password</label>
                        <input type=\"password\" class=\"form-control\" id=\"newPassword\" name=\"newPassword\">
                    </div>
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-secondary\" data-bs-dismiss=\"modal\">
                    <i class=\"bi bi-x-circle me-1\"></i> Close
                </button>
                <button type=\"button\" class=\"btn btn-primary update-password\">
                    <i class=\"bi bi-check2-circle me-1\"></i> Save Changes
                </button>
            </div>
        </div>
    </div>
</div>";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "profile/update_password_modal.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "profile/update_password_modal.twig", "C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\views\\profile\\update_password_modal.twig");
    }
}
