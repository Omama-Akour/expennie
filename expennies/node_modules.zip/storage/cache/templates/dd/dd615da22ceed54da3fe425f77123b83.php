<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* emails/signup.html.twig */
class __TwigTemplate_069b5fa354993d9c41c912efe96e7be8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "Thank you for signing up to Expennies. Please <a href=\"";
        echo twig_escape_filter($this->env, ($context["activationLink"] ?? null), "html", null, true);
        echo "\" target=\"_blank\">click here</a> to activate your account.
<br />The link is valid until ";
        // line 2
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, ($context["expirationDate"] ?? null), "m/d/Y g:i A"), "html", null, true);
        echo ".";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "emails/signup.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  42 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "emails/signup.html.twig", "C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\views\\emails\\signup.html.twig");
    }
}
