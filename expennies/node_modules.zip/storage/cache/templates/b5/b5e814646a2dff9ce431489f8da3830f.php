<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard.twig */
class __TwigTemplate_666b588d4beb6fa2ffcbb0a7689e34e5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.twig", "dashboard.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    ";
        // line 5
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("dashboard");
        echo "
";
    }

    // line 8
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    ";
        // line 10
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("dashboard");
        echo "
";
    }

    // line 13
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Dashboard";
    }

    // line 15
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 16
        echo "    <div class=\"dashboard\">
        <div class=\"top-container mb-4 row g-0 rounded-4\">
            <div class=\"col-8 border-end border-3\">
                <div class=\"row text-center\">
                    <div class=\"col p-4 pb-0 fs-1\">";
        // line 20
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "M, Y"), "html", null, true);
        echo "</div>
                </div>
                <div class=\"row justify-content-between text-center\">
                    <div class=\"col p-4 pb-0 fs-2\">
                        <div>Expense</div>
                        <div class=\"fw-bold text-danger\">\$";
        // line 25
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["totals"] ?? null), "expense", [], "any", false, false, false, 25), 2), "html", null, true);
        echo "</span></div>
                    </div>
                    <div class=\"col p-4 pb-0 fs-2\">
                        <div>Income</div>
                        <div class=\"fw-bold text-success\">\$";
        // line 29
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["totals"] ?? null), "income", [], "any", false, false, false, 29), 2), "html", null, true);
        echo "</div>
                    </div>
                    <div class=\"col p-4 pb-0 fs-2\">
                        <div>Net</div>
                        <div class=\"fw-bold ";
        // line 33
        echo (((twig_get_attribute($this->env, $this->source, ($context["totals"] ?? null), "net", [], "any", false, false, false, 33) >= 0)) ? ("text-success") : ("text-danger"));
        echo "\">
                            \$";
        // line 34
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["totals"] ?? null), "net", [], "any", false, false, false, 34), 2), "html", null, true);
        echo "
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col p-4\">
                        <div class=\"fs-1 text-center mb-2\">";
        // line 40
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " Summary</div>
                        <canvas id=\"yearToDateChart\"></canvas>
                    </div>
                </div>
            </div>
            <div class=\"col p-4\">
                <h4>Recent Transactions</h4>
                <table class=\"table\">
                    <tbody>
                        ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["transactions"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["transaction"]) {
            // line 50
            echo "                            <tr>
                                <td>";
            // line 51
            echo twig_escape_filter($this->env, twig_slice($this->env, twig_get_attribute($this->env, $this->source, $context["transaction"], "description", [], "any", false, false, false, 51), 0, 20), "html", null, true);
            echo "</td>
                                <td class=\"";
            // line 52
            echo (((twig_get_attribute($this->env, $this->source, $context["transaction"], "amount", [], "any", false, false, false, 52) > 0)) ? ("text-success fw-bold") : (""));
            echo "\">
                                    ";
            // line 53
            echo (((twig_get_attribute($this->env, $this->source, $context["transaction"], "amount", [], "any", false, false, false, 53) < 0)) ? ("-") : (""));
            echo "\$";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, abs(twig_get_attribute($this->env, $this->source, $context["transaction"], "amount", [], "any", false, false, false, 53)), 2), "html", null, true);
            echo "
                                </td>
                                <td>
                                    <div>";
            // line 56
            ((twig_get_attribute($this->env, $this->source, $context["transaction"], "category", [], "any", false, false, false, 56)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["transaction"], "category", [], "any", false, false, false, 56), "name", [], "any", false, false, false, 56), "html", null, true))) : (print ("N/A")));
            echo "</div>
                                    <div>";
            // line 57
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["transaction"], "date", [], "any", false, false, false, 57), "m/d/Y"), "html", null, true);
            echo "</div>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['transaction'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "                    </tbody>
                </table>
            </div>
        </div>
        <div class=\"categories-container row\">
            ";
        // line 66
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["topSpendingCategories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["spendingCategory"]) {
            // line 67
            echo "                <div class=\"col\">
                    <div class=\"category-card p-4 text-center d-flex align-items-center justify-content-center\">
                        <div>
                            <h6 class=\"fs-6 fw-normal\">";
            // line 70
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["spendingCategory"], "name", [], "any", false, false, false, 70), "html", null, true);
            echo "</h6>
                            <h1 class=\"fs-1 text-danger text-opacity-75\">\$";
            // line 71
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["spendingCategory"], "total", [], "any", false, false, false, 71), "html", null, true);
            echo "</h1>
                        </div>
                    </div>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['spendingCategory'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 76
        echo "        </div>
    </div>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "dashboard.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  211 => 76,  200 => 71,  196 => 70,  191 => 67,  187 => 66,  180 => 61,  170 => 57,  166 => 56,  158 => 53,  154 => 52,  150 => 51,  147 => 50,  143 => 49,  131 => 40,  122 => 34,  118 => 33,  111 => 29,  104 => 25,  96 => 20,  90 => 16,  86 => 15,  79 => 13,  73 => 10,  68 => 9,  64 => 8,  58 => 5,  53 => 4,  49 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard.twig", "C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\views\\dashboard.twig");
    }
}
