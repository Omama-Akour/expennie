<?php

declare(strict_types = 1);

use App\Command\GenerateAppKeyCommand;

return [
    GenerateAppKeyCommand::class,
];