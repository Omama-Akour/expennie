<?php
/* Smarty version 4.4.1, created on 2024-03-19 12:36:16
  from 'C:\xampp\htdocs\expennies-P0_Start\resources\views\layout.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65f978b04402d5_57305953',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ec7e6f1c5f04b9de19cfe3dd2c0bb411c8e87e6e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\views\\layout.tpl',
      1 => 1710848170,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\css\\app.scss' => 1,
    'file:C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\js\\app.js' => 1,
  ),
),false)) {
function content_65f978b04402d5_57305953 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-gray-100">
<head>
    <meta charset="UTF-8">
    <meta id="csrfName" name="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['keys']['name'];?>
" content="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['name'];?>
">
    <meta id="csrfValue" name="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['keys']['value'];?>
" content="<?php echo $_smarty_tpl->tpl_vars['csrf']->value['value'];?>
">
    <title><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_125794101665f978b0396807_41612638', 'title');
?>
</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_55392944865f978b0397265_61374632', 'stylesheets');
?>


    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18494466465f978b03dee26_44295267', 'javascripts');
?>

</head>
<body>
<div class="container">
    <header class="d-flex flex-wrap justify-content-center align-items-center py-3 mb-4">
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <img src="<?php echo (defined('IMG_DIR') ? constant('IMG_DIR') : null);?>
/logo.png" width="64" height="64" alt="Expennies Logo" />
            <span class="fs-1 fw-bold">Ex<span class="text-primary">pennies</span></span>
        </a>

        <ul class="nav nav-pills align-items-center">
            <li class="nav-item">
                <a href="/" class="nav-link fw-bold fs-5 <?php if ($_smarty_tpl->tpl_vars['current_route']->value == 'home') {?>active<?php }?>" aria-current="page">Overview</a>
            </li>
            <li class="nav-item">
                <a href="/transactions" class="nav-link fw-bold fs-5 <?php if ($_smarty_tpl->tpl_vars['current_route']->value == 'transactions') {?>active<?php }?>" aria-current="page">Transactions</a>
            </li>
            <li class="nav-item">
                <a href="/categories" class="nav-link fw-bold fs-5 <?php if ($_smarty_tpl->tpl_vars['current_route']->value == 'categories') {?>active<?php }?>" aria-current="page">Categories</a>
            </li>
        </ul>

        <div class="dropdown user-dropdown-menu">
            <a href="#" class="text-decoration-none d-flex align-items-center" id="userDropDownMenu" data-bs-toggle="dropdown"
               aria-expanded="false">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon">
                    <path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clip-rule="evenodd" />
                </svg>
                <span><?php echo $_smarty_tpl->tpl_vars['auth']->value['name'];?>
</span>
            </a>
            <ul class="dropdown-menu" aria-labelledby="userDropDownMenu">
                <li>
                    <a href="/profile" class="dropdown-item">Profile</a>
                </li>
                <li>
                    <form action="/logout" method="post">
                        <?php echo $_smarty_tpl->tpl_vars['csrf']->value['fields'];?>

                        <button class="dropdown-item">Log Out</button>
                    </form>
                </li>
            </ul>
        </div>
    </header>
</div>
<div class="container">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_36722374565f978b043fc41_18423855', 'content');
?>

</div>
</body>
</html>
<?php }
/* {block 'title'} */
class Block_125794101665f978b0396807_41612638 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_125794101665f978b0396807_41612638',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Expennies<?php
}
}
/* {/block 'title'} */
/* {block 'stylesheets'} */
class Block_55392944865f978b0397265_61374632 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'stylesheets' => 
  array (
    0 => 'Block_55392944865f978b0397265_61374632',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <?php $_smarty_tpl->_subTemplateRender('file:C:\xampp\htdocs\expennies-P0_Start\resources\css\app.scss', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php
}
}
/* {/block 'stylesheets'} */
/* {block 'javascripts'} */
class Block_18494466465f978b03dee26_44295267 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'javascripts' => 
  array (
    0 => 'Block_18494466465f978b03dee26_44295267',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <?php $_smarty_tpl->_subTemplateRender('file:C:\xampp\htdocs\expennies-P0_Start\resources\js\app.js', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php
}
}
/* {/block 'javascripts'} */
/* {block 'content'} */
class Block_36722374565f978b043fc41_18423855 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_36722374565f978b043fc41_18423855',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'content'} */
}
