<?php
/* Smarty version 4.4.1, created on 2024-03-19 11:51:59
  from 'C:\xampp\htdocs\expennies-P0_Start\resources\js\app.js' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65f96e4f9ce4d6_82515775',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4de0fcddce9a33825a50e529023ffbbaeb31bb71' => 
    array (
      0 => 'C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\js\\app.js',
      1 => 1709186550,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65f96e4f9ce4d6_82515775 (Smarty_Internal_Template $_smarty_tpl) {
?>import "../css/app.scss"

require('bootstrap')
<?php }
}
