<?php
/* Smarty version 4.4.1, created on 2024-03-19 12:21:52
  from 'C:\xampp\htdocs\expennies-P0_Start\resources\views\categories\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65f975509fde22_06230417',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5487c3a5dde840529fba2dcf0705d005dc079cca' => 
    array (
      0 => 'C:\\xampp\\htdocs\\expennies-P0_Start\\resources\\views\\categories\\index.tpl',
      1 => 1710847309,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:categories/edit_category_modal.tpl' => 1,
  ),
),false)) {
function content_65f975509fde22_06230417 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19850300765f975509f9047_91341128', 'javascripts');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_137698309065f975509f9ab9_19309016', 'title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_101190748665f975509f9f05_54860175', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, 'layout.tpl');
}
/* {block 'javascripts'} */
class Block_19850300765f975509f9047_91341128 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'javascripts' => 
  array (
    0 => 'Block_19850300765f975509f9047_91341128',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php
}
}
/* {/block 'javascripts'} */
/* {block 'title'} */
class Block_137698309065f975509f9ab9_19309016 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_137698309065f975509f9ab9_19309016',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Categories<?php
}
}
/* {/block 'title'} */
/* {block 'content'} */
class Block_101190748665f975509f9f05_54860175 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_101190748665f975509f9f05_54860175',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="categories container content-body">
        <div class="text-end mb-4">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newCategoryModal">
                <i class="bi bi-plus-circle me-1"></i>
                New Category
            </button>
        </div>
        <div class="modal fade" id="newCategoryModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <form action="/categories" method="post">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">New Category</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php echo $_smarty_tpl->tpl_vars['csrf']->value['fields'];?>

                            <div class="form-outline form-white mb-4">
                                <input type="text" name="name" required
                                       class="form-control form-control-lg"
                                       placeholder="Category Name" />
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="bi bi-x-circle me-1"></i>
                                Close
                            </button>
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-check-circle me-1"></i>
                                Create
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php $_smarty_tpl->_subTemplateRender('file:categories/edit_category_modal.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        <div>
            <table id="categoriesTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
<?php
}
}
/* {/block 'content'} */
}
